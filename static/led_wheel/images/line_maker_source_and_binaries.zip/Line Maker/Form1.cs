using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Line_Maker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            initDots();
        }

        private void dotDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            ((PictureBox)sender).BackColor = currentColor.BackColor;
        }

        private void dotUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {

        }

        private void dotEnter(object sender, EventArgs e)
        {

        }

        private void dotLeave(object sender, EventArgs e)
        {

        }

        private void initDots()
        {
            dots = new PictureBox[100, 16];

            int xspacer = 1;
            for (int i = 0; i < 100; i++)
            {
                int yspacer = 1;
                for (int j = 0; j < 16; j++)
                {                   
                    dots[i, j] = new PictureBox();
                    dots[i, j].Name = "dot_" + i + "_" + j;
                    dots[i, j].Size = new Size(9, 9);
                    dots[i, j].Location = new Point((i * 9) + xspacer, (j * 9) + yspacer);
                    dots[i, j].BackColor = Color.Black;
                    dots[i, j].Visible = true;
                    dots[i, j].BackgroundImage = Line_Maker.Properties.Resources.dot9x9;
                    dots[i, j].MouseDown += new System.Windows.Forms.MouseEventHandler(this.dotDown);
                    dots[i, j].MouseUp += new System.Windows.Forms.MouseEventHandler(this.dotUp);
                    dots[i, j].MouseEnter += new EventHandler(this.dotEnter);
                    dots[i, j].MouseLeave += new EventHandler(this.dotLeave);


                    this.Controls.Add(dots[i, j]);
                    yspacer++;                    
                }
                xspacer++;
            }
        }
        
        private void redSwatch_Click(object sender, EventArgs e)
        {
            currentColor.BackColor = ((PictureBox)sender).BackColor;
        }

        private void blueSwatch_Click(object sender, EventArgs e)
        {
            currentColor.BackColor = ((PictureBox)sender).BackColor;
        }

        private void greenSwatch_Click(object sender, EventArgs e)
        {
            currentColor.BackColor = ((PictureBox)sender).BackColor;
        }

        private void blackSwatch_Click(object sender, EventArgs e)
        {
            currentColor.BackColor = ((PictureBox)sender).BackColor;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void generate_code_button_Click(object sender, EventArgs e)
        {
            hexBufferCharCount = 0;
            lineBuffer = "";
            codeBuffer = "";
            codeBuffer += "line_array[100][72] = \n{\n";

            // read all the color values and write values to file
            for (int i = 0; i < 100; i++)
            {
                codeBuffer += "{";
                // blue
                for (int j = 0; j < 16; j++)
                {
                    appendOutputString(dots[i, j].BackColor.B);
                }

                codeBuffer += lineBuffer.Substring(0, lineBuffer.Length - 1) + "\n";
                lineBuffer = "";

                // green
                for (int j = 0; j < 16; j++)
                {
                    appendOutputString(dots[i, j].BackColor.G);
                }

                codeBuffer += lineBuffer.Substring(0, lineBuffer.Length - 1) + "\n";
                lineBuffer = "";

                // red
                for (int j = 0; j < 16; j++)
                {
                    appendOutputString(dots[i, j].BackColor.R);
                }

                codeBuffer += lineBuffer.Substring(0, lineBuffer.Length - 2);
                codeBuffer += "},\n";
                lineBuffer = "";                
            }

            codeBuffer = codeBuffer.Substring(0, codeBuffer.Length - 2);
            codeBuffer += "};\n";

            debugBox.Text = codeBuffer;
        }

        private int upscaleColorInt(int original)
        {
            return original * 16;
        }

        private void appendOutputString(int value)
        {
            string hexString = upscaleColorInt(value).ToString("X");

            hexString = hexString.PadRight(3, '0');

            foreach (char c in hexString)
            {
                if (hexBufferCharCount == 0)
                {
                    lineBuffer += "0x";
                }

                lineBuffer += c;

                hexBufferCharCount++;

                if (hexBufferCharCount == 2)
                {
                    lineBuffer += ", ";
                    hexBufferCharCount = 0;
                }
            }
        }
        private string codeBuffer;
        private int hexBufferCharCount;
        private string lineBuffer;
        private PictureBox[,] dots;

        private void fillButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    dots[i, j].BackColor = currentColor.BackColor;
                }
            }
        }

        
        
    }
}