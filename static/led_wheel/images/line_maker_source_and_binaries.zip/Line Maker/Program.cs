using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Line_Maker
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //MyFilterClass myFilterClassInstance = new MyFilterClass();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.AddMessageFilter(myFilterClassInstance);
            Application.Run(new Form1());
        }
    }

    /*public class MyFilterClass : IMessageFilter
    {
        public bool PreFilterMessage(ref Message m)
        {
            if (m.Msg == WM_MOUSEMOVE)
                // Check if mouse is over my picture box!

                return false;
        }
    }*/
}