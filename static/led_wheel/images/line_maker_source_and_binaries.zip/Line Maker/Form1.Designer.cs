namespace Line_Maker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.generate_code_button = new System.Windows.Forms.Button();
            this.currentColorLabel = new System.Windows.Forms.Label();
            this.colorSwatchesLabel = new System.Windows.Forms.Label();
            this.blackSwatch = new System.Windows.Forms.PictureBox();
            this.greenSwatch = new System.Windows.Forms.PictureBox();
            this.blueSwatch = new System.Windows.Forms.PictureBox();
            this.redSwatch = new System.Windows.Forms.PictureBox();
            this.currentColor = new System.Windows.Forms.PictureBox();
            this.debugBox = new System.Windows.Forms.TextBox();
            this.fillButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.blackSwatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenSwatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueSwatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redSwatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentColor)).BeginInit();
            this.SuspendLayout();
            // 
            // generate_code_button
            // 
            this.generate_code_button.Location = new System.Drawing.Point(8, 250);
            this.generate_code_button.Name = "generate_code_button";
            this.generate_code_button.Size = new System.Drawing.Size(137, 32);
            this.generate_code_button.TabIndex = 17;
            this.generate_code_button.Text = "Generate Code";
            this.generate_code_button.UseVisualStyleBackColor = true;
            this.generate_code_button.Click += new System.EventHandler(this.generate_code_button_Click);
            // 
            // currentColorLabel
            // 
            this.currentColorLabel.AutoSize = true;
            this.currentColorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentColorLabel.Location = new System.Drawing.Point(4, 190);
            this.currentColorLabel.Name = "currentColorLabel";
            this.currentColorLabel.Size = new System.Drawing.Size(116, 20);
            this.currentColorLabel.TabIndex = 18;
            this.currentColorLabel.Text = "Current Color";
            // 
            // colorSwatchesLabel
            // 
            this.colorSwatchesLabel.AutoSize = true;
            this.colorSwatchesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorSwatchesLabel.Location = new System.Drawing.Point(172, 189);
            this.colorSwatchesLabel.Name = "colorSwatchesLabel";
            this.colorSwatchesLabel.Size = new System.Drawing.Size(134, 20);
            this.colorSwatchesLabel.TabIndex = 19;
            this.colorSwatchesLabel.Text = "Color Swatches";
            // 
            // blackSwatch
            // 
            this.blackSwatch.BackColor = System.Drawing.Color.Black;
            this.blackSwatch.Location = new System.Drawing.Point(285, 214);
            this.blackSwatch.Name = "blackSwatch";
            this.blackSwatch.Size = new System.Drawing.Size(30, 30);
            this.blackSwatch.TabIndex = 24;
            this.blackSwatch.TabStop = false;
            this.blackSwatch.Click += new System.EventHandler(this.blackSwatch_Click);
            // 
            // greenSwatch
            // 
            this.greenSwatch.BackColor = System.Drawing.Color.Green;
            this.greenSwatch.Location = new System.Drawing.Point(249, 214);
            this.greenSwatch.Name = "greenSwatch";
            this.greenSwatch.Size = new System.Drawing.Size(30, 30);
            this.greenSwatch.TabIndex = 23;
            this.greenSwatch.TabStop = false;
            this.greenSwatch.Click += new System.EventHandler(this.greenSwatch_Click);
            // 
            // blueSwatch
            // 
            this.blueSwatch.BackColor = System.Drawing.Color.Blue;
            this.blueSwatch.Location = new System.Drawing.Point(213, 214);
            this.blueSwatch.Name = "blueSwatch";
            this.blueSwatch.Size = new System.Drawing.Size(30, 30);
            this.blueSwatch.TabIndex = 22;
            this.blueSwatch.TabStop = false;
            this.blueSwatch.Click += new System.EventHandler(this.blueSwatch_Click);
            // 
            // redSwatch
            // 
            this.redSwatch.BackColor = System.Drawing.Color.Red;
            this.redSwatch.Location = new System.Drawing.Point(177, 214);
            this.redSwatch.Name = "redSwatch";
            this.redSwatch.Size = new System.Drawing.Size(30, 30);
            this.redSwatch.TabIndex = 21;
            this.redSwatch.TabStop = false;
            this.redSwatch.Click += new System.EventHandler(this.redSwatch_Click);
            // 
            // currentColor
            // 
            this.currentColor.BackColor = System.Drawing.Color.Red;
            this.currentColor.Location = new System.Drawing.Point(10, 214);
            this.currentColor.Name = "currentColor";
            this.currentColor.Size = new System.Drawing.Size(30, 30);
            this.currentColor.TabIndex = 20;
            this.currentColor.TabStop = false;
            // 
            // debugBox
            // 
            this.debugBox.Location = new System.Drawing.Point(8, 288);
            this.debugBox.Multiline = true;
            this.debugBox.Name = "debugBox";
            this.debugBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.debugBox.Size = new System.Drawing.Size(984, 258);
            this.debugBox.TabIndex = 25;
            // 
            // fillButton
            // 
            this.fillButton.Location = new System.Drawing.Point(152, 250);
            this.fillButton.Name = "fillButton";
            this.fillButton.Size = new System.Drawing.Size(127, 32);
            this.fillButton.TabIndex = 26;
            this.fillButton.Text = "Fill Button";
            this.fillButton.UseVisualStyleBackColor = true;
            this.fillButton.Click += new System.EventHandler(this.fillButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1001, 558);
            this.Controls.Add(this.fillButton);
            this.Controls.Add(this.debugBox);
            this.Controls.Add(this.blackSwatch);
            this.Controls.Add(this.greenSwatch);
            this.Controls.Add(this.blueSwatch);
            this.Controls.Add(this.redSwatch);
            this.Controls.Add(this.currentColor);
            this.Controls.Add(this.colorSwatchesLabel);
            this.Controls.Add(this.currentColorLabel);
            this.Controls.Add(this.generate_code_button);
            this.Name = "Form1";
            this.Text = "Line Maker";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.blackSwatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenSwatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueSwatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redSwatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentColor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button generate_code_button;
        private System.Windows.Forms.Label currentColorLabel;
        private System.Windows.Forms.Label colorSwatchesLabel;
        private System.Windows.Forms.PictureBox currentColor;
        private System.Windows.Forms.PictureBox redSwatch;
        private System.Windows.Forms.PictureBox blueSwatch;
        private System.Windows.Forms.PictureBox greenSwatch;
        private System.Windows.Forms.PictureBox blackSwatch;
        private System.Windows.Forms.TextBox debugBox;
        private System.Windows.Forms.Button fillButton;
    }
}

