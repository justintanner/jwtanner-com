#ifndef _RAW_PATTERN_H_
#define _RAW_PATTERN_H_

#include <avr/pgmspace.h>
#include "../led_controller/led_controller.h"

#define TOTAL_PATTERNS   4

#endif
