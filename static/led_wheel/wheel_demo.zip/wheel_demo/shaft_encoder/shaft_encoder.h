/**
 * @file   shaft_encoder.h
 * @author Justin Tanner
 * @date   Tue Aug 26 18:31:33 2008
 * 
 * @brief  Hamamatsu 5587, P5588 ( or very similar ) Shaft Encoder
 *
 *         This driver initalizes the shaft encoder, and setups a timer to read
 *         high-low transitions on the output of the shaft encoder.
 * 
 */

#ifndef _SHAFT_ENCODER_H_
#define _SHAFT_ENCODER_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include "../common.h"
#include "../led_controller/led_controller.h"

#define SHAFT_PORT            PORTC
#define SHAFT_DDR             DDRC
#define SHAFT_INPUT_PIN       PORTC7

/* desired lines per revolution is 200, divide by 8 to matches the timer frequency of 125000Hz */
#define LPR_ADJUSTED          25

void shaft_encoder_init(void);

#endif
