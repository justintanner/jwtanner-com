/**
 * @file   spi_master.c
 * @author Justin Tanner
 * @date   Sat Aug 16 19:15:43 2008
 * 
 * @brief  Serial Peripheral Interface Bus for the Atmel AT90USB1287
 *         This library sets up SPI master mode for AT90USB1287 
 * 
 */

#include "spi_master.h"

/** 
 * Initialize SPI master mode on the Atmel AT90USB1287
 * 
 * SPI is running at 2Mhz -- default setting Fosc / 4
 * 
 */
void spi_init(void)
{
    /* setup SPI output pins */
    DDRB |= _BV(SPI_MOSI) | _BV(SPI_CLK) | _BV(SPI_SS);

    /* setup SPI input pins */
    DDRB &= ~_BV(SPI_MISO);    

    /* pull SS high while configuring SPI in master mode */
    SPI_SS_HIGH();

    /* enable SPI in master mode @ 2Mhz */
    SPCR |= _BV(SPE) | _BV(MSTR);

    /* double SPI speed in master mode to 4Mhz */
    SPSR |= _BV(SPI2X);

    /* pull SS low to resume normal SPI operation */
    SPI_SS_LOW();
}
