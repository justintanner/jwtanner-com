/**
 * @file   spi_master.h
 * @author Justin Tanner
 * @date   Sat Aug 16 19:15:43 2008
 * 
 * @brief  Serial Peripheral Interface Bus for the Atmel AT90USB1287
 *         This library sets up SPI master mode for AT90USB1287 
 * 
 */

#ifndef _SPI_MASTER_H_
#define _SPI_MASTER_H_

#include <util/delay.h>
#include <avr/io.h>

#define SPI_PORT                PORTB
#define SPI_CLK                 PORTB1
#define SPI_MOSI                PORTB2
#define SPI_MISO                PORTB3
#define SPI_SS                  PORTB0

#define SPI_SS_HIGH()           SPI_PORT |= _BV(SPI_SS); _delay_us(5);
#define SPI_SS_LOW()            SPI_PORT &= ~_BV(SPI_SS); _delay_us(5);

#define SPI_WAIT()              while (!(SPSR & (1<<SPIF))) {};
#define SPI_SEND(x)             SPDR = x; SPI_WAIT();

void spi_init(void);

#endif
