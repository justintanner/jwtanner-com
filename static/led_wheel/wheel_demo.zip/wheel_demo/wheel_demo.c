/**
 * @file   wheel_demo.c
 * @author Justin Tanner
 * @date   Tue Aug 26 18:12:58 2008
 * 
 * @brief  LED Wheel Demo
 * 
 *         Display 4 pre-programmed patterns stored in the program memory.
 *
 */

#include <util/delay.h>
#include "common.h"
#include "spi_master/spi_master.h"
#include "led_controller/led_controller.h"
#include "shaft_encoder/shaft_encoder.h"

int main(int argc, char**argv)
{
    CLOCK_8MHZ();
    
    DISABLE_INTERRUPTS();
    
    shaft_encoder_init();
    
    spi_init();

    ENABLE_INTERRUPTS();
    
    led_controller_init();    

    for(;;)
    {
        led_controller_state_machine();
    };

    return 0;
}


