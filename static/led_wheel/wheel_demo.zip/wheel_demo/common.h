/**
 * @file   common.h
 * @author Scott Craig
 * @author Justin Tanner
 *
 *
 * @brief Common macros.
 *
 *  CSC 460/560 Real Time Operating Systems - Mantis Cheng
 *
 */


#ifndef __COMMON_H__
#define __COMMON_H__

/** Disable default prescaler to make processor speed 8 MHz. */
#define CLOCK_8MHZ()           CLKPR = (1<<CLKPCE); CLKPR = 0x00;

/** 8Mhz clock speed for delay functions */
#define F_CPU                  8000000UL

#define DISABLE_INTERRUPTS()    asm volatile ("cli"::)
#define ENABLE_INTERRUPTS()     asm volatile ("sei"::)
#define NOP()                  asm volatile ("nop"::)

#endif
