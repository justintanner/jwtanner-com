/**
 * @file   led_controller.h
 * @author Justin Tanner
 * @date   Thu Aug 21 21:37:57 2008
 * 
 * @brief  Led Controller drivers for 3 TLC5940NT led controller chips connected to
 *         16 common anode RGB LED's ( or 48 individual LED's ).
 *
 *         Uses SPI to send 192-bit bit data blocks representing the PWM power to
 *         send to each light.
 *
 *         Each color requires its own 192-bit data block, consisting of 16 x 12-bit numbers.
 *         The 12-bit numbers (4095 - 0) represents the PWM power sent to an individual LED.
 *
 *         The three 192-bit data blocks must be sent every time you wish to update the
 *         power of any LED.
 * 
 */

#ifndef _LED_CONTROLLER_H_
#define _LED_CONTROLLER_H_

#include <string.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include "../spi_master/spi_master.h"
#include "../raw_pattern/raw_pattern.h"

#define LEDC_PORT        PORTB
#define LEDC_DDR         DDRB
#define XLAT_PORT        PORTB7
#define BLANK_PORT       PORTB6

#define XLAT_HIGH()      LEDC_PORT |= _BV(XLAT_PORT)
#define XLAT_LOW()       LEDC_PORT &= ~_BV(XLAT_PORT)

#define BLANK_HIGH()     LEDC_PORT |= _BV(BLANK_PORT)
#define BLANK_LOW()      LEDC_PORT &= ~_BV(BLANK_PORT)

#define LED_COUNT        16

#define DATA_BLOCK_SIZE  72

#define LINE_COUNT       100

#define LED_TIMER_ON()   TCCR1B |= _BV(WGM12) | _BV(CS11);
#define LED_TIMER_OFF()  TCCR1B = 0;

#ifndef NOP
#define NOP()            asm volatile ("nop"::)
#endif

typedef enum
{
    LED_STATE_PROGRAM,
    LED_STATE_IDLE,    
    LED_STATE_CONFIG
} LED_STATE;

void led_controller_init(void);
void led_controller_send_buffer(uint8_t* buffer);
void led_controller_state_machine();

#endif
