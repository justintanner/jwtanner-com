 /**
 * @file   led_controller.c
 * @author Justin Tanner
 * @date   Thu Aug 21 21:37:57 2008
 * 
 * @brief  LED controller driver for 3 TLC5940NT led controller chips connected to
 *         16 common anode RGB LED's ( or 48 individual LED's ).
 *
 *         Uses SPI to send 192-bit bit data blocks representing the PWM power to
 *         send to each light.
 *
 *         Each color requires its own 192-bit data block, consisting of 16 x 12-bit numbers.
 *         The 12-bit numbers (4095 - 0) represents the PWM power sent to an individual LED.
 *
 *         Three 192-bit data blocks must be sent every time you wish to update the
 *         power of ANY light.
 * 
 */

#include "led_controller.h"

/** current pattern being displayed */
extern uint8_t current_pattern[LINE_COUNT][DATA_BLOCK_SIZE];

/** array of patterns stored in program memory */
extern uint8_t patterns[TOTAL_PATTERNS][LINE_COUNT][DATA_BLOCK_SIZE] PROGMEM;

/** count the number of rotations, used to switch patterns */
uint16_t volatile rotation_count;

/** counts the numbe of lines displayed ( color and blank lines ) */
uint16_t volatile interrupt_count = 0;

/** interrupt counter of timer1 used by the led controller */
uint16_t volatile line_count = 0;

/** state of the wheel arm during rotation */
LED_STATE volatile led_state = LED_STATE_PROGRAM;

/** index into the patters aray in program memory */
uint8_t current_pattern_index = 0;

/** 
 * Initialize LED controller ports
 * 
 */
void led_controller_init(void)
{
    /* setup the LEC controller control pins */
    LEDC_DDR |= _BV(XLAT_PORT) | _BV(BLANK_PORT);

    /* LED display timer: start output compare every 1ms */
    /* NOTE: this value will be updated by the shaft encoder */
    OCR1A = 1000;

    /* timer1 is running @ 1Mhz */
    LED_TIMER_ON();

    /* enable output compare 1A */
    TIMSK1 |= _BV(OCIE1A);
}

/** 
 * Dump a pre-formatted data block to SPI to be displayed by the
 * LED controllers
 * 
 * @param buffer 72-byte wide data buffer
 */
void led_controller_send_buffer(uint8_t* buffer)
{
    int i;

    /* dump buffer to SPI */
    for (i = 0; i < DATA_BLOCK_SIZE; i++)
    {
        SPI_SEND(buffer[i]);
    }
}

/** 
 * State machine controlling the LED display state
 * 
 * This state machine receives state changes from an ISR
 * 
 */
void led_controller_state_machine()
{
    int i, j;
    
    switch(led_state)
    {
        case LED_STATE_PROGRAM:

            /* toggle XLAT signal the led controller to save the last line receieved on SPI */
            XLAT_HIGH();
            NOP();
            NOP();
            XLAT_LOW();

            /* display line, and send next line via SPI */
            BLANK_LOW();
            led_controller_send_buffer(current_pattern[line_count]);
            BLANK_HIGH();
            
            led_state = LED_STATE_IDLE;

            line_count++;

            /* finished all lines, turn off timer and wait for the next rotation */
            if (interrupt_count >= 199)
            {
                LED_TIMER_OFF();
                led_state = LED_STATE_CONFIG;
            }
            
            break;
                
        case LED_STATE_IDLE:
            
            /* blank line */
            if (rotation_count >= 100)
            {
                current_pattern_index = (current_pattern_index + 1) % TOTAL_PATTERNS;
                
                /* copy in a new picture */
                for (i = 0; i < 100; i++)
                {
                    for (j = 0; j < 72; j++)
                    {
                        current_pattern[i][j] = pgm_read_byte(&(patterns[current_pattern_index][i][j]));
                    }
                }
                
                rotation_count = 0;
            }
            break;
                
        case LED_STATE_CONFIG:
            
            /* do nothing and wait for the shaft encoder */
            break;
    }
}

/** 
 * LED Timer: control the display of each ON line and OFF line
 * 
 * @param TIMER1_COMPA_vect 
 * 
 */
ISR(TIMER1_COMPA_vect)
{
    interrupt_count++;
    
    if ((interrupt_count % 2) == 1)
    {
        led_state = LED_STATE_PROGRAM;
    }
}


